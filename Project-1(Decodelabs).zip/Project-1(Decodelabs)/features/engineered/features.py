"""
features/engineered/feature_01.py  — Revenue Intensity Score
features/engineered/feature_02.py  — Order Efficiency Ratio
features/engineered/feature_03.py  — Customer Spend Tier

All 3 are defined here and imported by the main pipeline.
Each uses ONLY vectorized NumPy/Pandas operations.
"""

import pandas as pd
import numpy as np
import logging

logger = logging.getLogger(__name__)


# ── Feature 1: Revenue Intensity Score ───────────────────────────────────────
def add_revenue_intensity_score(df: pd.DataFrame) -> pd.DataFrame:
    """
    RevenueIntensityScore = TotalPrice / (Quantity × ItemsInCart)
    
    Captures how much revenue is generated per unit of cart activity.
    High score → premium, low-volume orders.
    Low score  → bulk, high-volume orders.
    """
    df = df.copy()
    denom = df["Quantity"].values * df["ItemsInCart"].values
    df["RevenueIntensityScore"] = np.where(
        denom > 0,
        df["TotalPrice"].values / denom,
        0.0
    )
    logger.info("  Feature 1: RevenueIntensityScore = TotalPrice / (Quantity × ItemsInCart)")
    return df


# ── Feature 2: Price Deviation from Category Mean ────────────────────────────
def add_price_deviation(df: pd.DataFrame) -> pd.DataFrame:
    """
    PriceDeviation = UnitPrice - mean(UnitPrice per Product category)
    
    Captures whether this order's unit price is above or below
    the average for its product category. Signals premium vs discount orders.
    Uses vectorized groupby transform — no Python loops.
    """
    df = df.copy()
    category_mean = df.groupby("Product")["UnitPrice"].transform("mean")
    df["PriceDeviation"] = df["UnitPrice"].values - category_mean.values
    logger.info("  Feature 2: PriceDeviation = UnitPrice - CategoryMeanPrice (vectorized groupby)")
    return df


# ── Feature 3: Customer Spend Tier ───────────────────────────────────────────
def add_spend_tier(df: pd.DataFrame) -> pd.DataFrame:
    """
    SpendTier = pd.cut(TotalPrice, 4 equal-width bins) → ordinal 0–3
    
    Buckets orders into Low / Medium / High / Premium spend tiers.
    Useful as a categorical target proxy or a grouping feature.
    Fully vectorized — no loops.
    """
    df = df.copy()
    df["SpendTier"] = pd.cut(
        df["TotalPrice"],
        bins=4,
        labels=[0, 1, 2, 3],   # 0=Low, 1=Medium, 2=High, 3=Premium
        include_lowest=True
    ).astype(int)
    tier_counts = df["SpendTier"].value_counts().sort_index()
    logger.info(f"  Feature 3: SpendTier distribution:\n{tier_counts.to_string()}")
    return df


def add_all_engineered_features(df: pd.DataFrame) -> pd.DataFrame:
    """Apply all 3 engineered features in sequence."""
    logger.info("=== Engineering New Predictive Features ===")
    df = add_revenue_intensity_score(df)
    df = add_price_deviation(df)
    df = add_spend_tier(df)
    logger.info(f"  3 features added. New shape: {df.shape}")
    return df


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    df = pd.read_excel("data/raw/dataset.xlsx")
    df = add_all_engineered_features(df)
    print(df[["TotalPrice", "RevenueIntensityScore", "PriceDeviation", "SpendTier"]].head(10))
    print(df[["RevenueIntensityScore", "PriceDeviation", "SpendTier"]].describe())
