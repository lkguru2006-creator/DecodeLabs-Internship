"""
main.py — Enterprise Pipeline Orchestrator
Data Science Project 1 | Advanced EDA & Feature Engineering

Execution order:
  Phase 1 (Input)   → missing data → outliers → distribution guard
  Phase 2 (Process) → date features → revenue features → encoding → collinearity
  Phase 3 (Output)  → engineered features → contracts → feature store → temporal split

Run from project root:
  python main.py
"""

import logging
import os
import sys
import yaml
import pandas as pd
import numpy as np

# ── Logging setup ─────────────────────────────────────────────────────────────
os.makedirs("logs", exist_ok=True)
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
    handlers=[
        logging.FileHandler("logs/pipeline.log"),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger("main")

# ── Project root on path ──────────────────────────────────────────────────────
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from src.input.missing_data       import handle_missing_data
from src.input.outlier_handler     import handle_outliers
from src.input.distribution_guard  import check_distribution_variance, run_normality_check
from src.process.vectorizer        import vectorized_date_features, vectorized_revenue_features
from src.process.encoder           import encode_features
from src.process.collinearity      import remove_collinearity
from src.output.schema_contracts   import validate_raw_input, validate_processed_output
from src.output.point_in_time      import (create_temporal_train_test_split,
                                            add_event_timestamp, check_for_leakage)
from src.output.feature_store      import push_to_offline_store, push_to_online_store
from features.engineered.features  import add_all_engineered_features


def load_config(path: str = "configs/pipeline_config.yaml") -> dict:
    with open(path) as f:
        return yaml.safe_load(f)


def run_pipeline():
    cfg = load_config()
    logger.info("=" * 70)
    logger.info("  DS PROJECT 1 — IPO Pipeline START")
    logger.info("=" * 70)

    # ── LOAD RAW DATA ─────────────────────────────────────────────────────────
    logger.info("\n[LOAD] Reading raw dataset...")
    df_raw = pd.read_excel(cfg["pipeline"]["dataset"])
    logger.info(f"  Raw shape: {df_raw.shape}")

    # ── PHASE 1: INPUT FIDELITY ───────────────────────────────────────────────
    logger.info("\n" + "─" * 50)
    logger.info("PHASE 1: Securing Input Fidelity")
    logger.info("─" * 50)

    # Step 1a: Validate raw schema (Pandera)
    try:
        df_raw = validate_raw_input(df_raw)
    except Exception as e:
        logger.warning(f"  Schema warning (non-fatal): {e}")

    # Step 1b: Handle missing data
    df = handle_missing_data(df_raw.copy())

    # Step 1c: Handle outliers via IQR + winsorization
    df = handle_outliers(df, save_plots=True)

    # Step 1d: Distribution variance guard
    logger.info("\n  Distribution variance check:")
    variance_report = check_distribution_variance(df_raw, df)
    for col, stats in variance_report.items():
        logger.info(f"    {col}: std change {stats['std_change_pct']}% [{stats['status']}]")

    # Save interim checkpoint
    os.makedirs("data/interim", exist_ok=True)
    df.to_csv(cfg["pipeline"]["output_interim"], index=False)
    logger.info(f"\n  ✓ Phase 1 complete → {cfg['pipeline']['output_interim']}")

    # ── PHASE 2: VECTORIZED COMPUTATION ──────────────────────────────────────
    logger.info("\n" + "─" * 50)
    logger.info("PHASE 2: Vectorized Computation Engine")
    logger.info("─" * 50)

    # Step 2a: Vectorized date features
    df = vectorized_date_features(df)

    # Step 2b: Vectorized revenue features
    df = vectorized_revenue_features(df)

    # Step 2c: Encode categoricals
    df_encoded = encode_features(df)

    # Step 2d: Collinearity eradication (on numeric columns only)
    numeric_for_corr = df_encoded.select_dtypes(include=[np.number]).copy()
    result = remove_collinearity(numeric_for_corr, save_heatmap=True)
    if isinstance(result, tuple):
        _, dropped_cols = result
        df_encoded = df_encoded.drop(columns=[c for c in dropped_cols if c in df_encoded.columns])
    logger.info(f"\n  ✓ Phase 2 complete. Shape: {df_encoded.shape}")

    # ── PHASE 3: CONTRACTS & SERVING ─────────────────────────────────────────
    logger.info("\n" + "─" * 50)
    logger.info("PHASE 3: Statistical Contracts & Serving")
    logger.info("─" * 50)

    # Step 3a: Engineer 3 new predictive features (on pre-encoded df to retain Product col)
    df_features = add_all_engineered_features(df)

    # Merge engineered features into encoded df
    for col in ["RevenueIntensityScore", "PriceDeviation", "SpendTier"]:
        if col in df_features.columns:
            df_encoded[col] = df_features[col].values

    # Step 3b: Validate processed output schema
    try:
        validate_processed_output(df_encoded)
    except Exception as e:
        logger.warning(f"  Processed schema warning (non-fatal): {e}")

    # Step 3c: Temporal split — point-in-time correct
    df_for_split = df.copy()
    df_for_split["RevenueIntensityScore"] = df_features["RevenueIntensityScore"].values
    df_for_split["PriceDeviation"]        = df_features["PriceDeviation"].values
    df_for_split["SpendTier"]             = df_features["SpendTier"].values

    df_train, df_test = create_temporal_train_test_split(df_for_split)
    df_train = add_event_timestamp(df_train)
    df_test  = add_event_timestamp(df_test)
    leakage_ok = check_for_leakage(df_train, df_test)

    # Step 3d: Push to feature store
    push_to_offline_store(df_train)
    push_to_online_store(df_train)

    # Step 3e: Save final processed dataset
    os.makedirs("data/processed", exist_ok=True)
    df_encoded.to_csv(cfg["pipeline"]["output_processed"], index=False)
    logger.info(f"\n  ✓ Phase 3 complete → {cfg['pipeline']['output_processed']}")

    # ── SUMMARY ───────────────────────────────────────────────────────────────
    logger.info("\n" + "=" * 70)
    logger.info("  PIPELINE COMPLETE")
    logger.info(f"  Raw rows:        {len(df_raw)}")
    logger.info(f"  Processed rows:  {len(df_encoded)}")
    logger.info(f"  Final features:  {df_encoded.shape[1]}")
    logger.info(f"  Train rows:      {len(df_train)}")
    logger.info(f"  Test rows:       {len(df_test)}")
    logger.info(f"  Leakage check:   {'PASSED ✓' if leakage_ok else 'FAILED ✗'}")
    logger.info("=" * 70)

    return df_encoded, df_train, df_test


if __name__ == "__main__":
    run_pipeline()
