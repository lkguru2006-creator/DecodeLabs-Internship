"""
Phase 1 — Input Fidelity
outlier_handler.py

Strategy:
  - Detect outliers via IQR (Q1 - 1.5*IQR, Q3 + 1.5*IQR)
  - Winsorize using numpy.clip() — preserves row count & sequential integrity
  - Never drop rows unless explicitly configured
"""

import logging
import pandas as pd
import numpy as np
import yaml
import matplotlib.pyplot as plt
import os

logger = logging.getLogger(__name__)


def load_config(config_path: str = "configs/imputation_config.yaml") -> dict:
    with open(config_path) as f:
        return yaml.safe_load(f)


def compute_iqr_bounds(series: pd.Series, multiplier: float = 1.5) -> tuple:
    """Return (lower_bound, upper_bound) using IQR fence."""
    Q1 = series.quantile(0.25)
    Q3 = series.quantile(0.75)
    IQR = Q3 - Q1
    lower = Q1 - multiplier * IQR
    upper = Q3 + multiplier * IQR
    return lower, upper


def detect_outliers(df: pd.DataFrame, col: str, multiplier: float = 1.5) -> pd.Series:
    """Return boolean mask where True = outlier."""
    lower, upper = compute_iqr_bounds(df[col], multiplier)
    return (df[col] < lower) | (df[col] > upper)


def winsorize_column(series: pd.Series, lower: float, upper: float) -> pd.Series:
    """Clip values to [lower, upper] — preserves row count."""
    return pd.Series(np.clip(series.values, lower, upper), index=series.index)


def handle_outliers(
    df: pd.DataFrame,
    config_path: str = "configs/imputation_config.yaml",
    save_plots: bool = True,
    figures_dir: str = "reports/figures/"
) -> pd.DataFrame:
    """
    Detect and winsorize outliers for all configured numeric columns.
    Saves before/after box plots to reports/figures/.
    """
    cfg = load_config(config_path)["outliers"]
    multiplier   = cfg.get("iqr_multiplier", 1.5)
    numeric_cols = cfg.get("numeric_columns", [])

    df = df.copy()

    logger.info("=== Outlier Detection & Winsorization ===")

    for col in numeric_cols:
        if col not in df.columns:
            logger.warning(f"  Column '{col}' not found — skipping")
            continue

        lower, upper = compute_iqr_bounds(df[col], multiplier)
        outlier_mask = (df[col] < lower) | (df[col] > upper)
        n_outliers   = outlier_mask.sum()

        logger.info(f"  '{col}': {n_outliers} outliers | bounds [{lower:.2f}, {upper:.2f}]")

        if save_plots and n_outliers > 0:
            _save_boxplot(df[col], col, lower, upper, figures_dir)

        # Winsorize — numpy.clip preserves row count and sequential integrity
        df[col] = winsorize_column(df[col], lower, upper)

        clipped = ((df[col] == lower) | (df[col] == upper)).sum()
        logger.info(f"    → {clipped} values clipped via numpy.clip()")

    return df


def _save_boxplot(series: pd.Series, col: str, lower: float, upper: float, figures_dir: str):
    os.makedirs(figures_dir, exist_ok=True)
    fig, axes = plt.subplots(1, 2, figsize=(10, 4))
    axes[0].boxplot(series.dropna())
    axes[0].axhline(lower, color="red",   linestyle="--", label=f"Lower: {lower:.2f}")
    axes[0].axhline(upper, color="orange",linestyle="--", label=f"Upper: {upper:.2f}")
    axes[0].set_title(f"{col} — Before Winsorization")
    axes[0].legend()

    clipped = np.clip(series.values, lower, upper)
    axes[1].boxplot(clipped)
    axes[1].set_title(f"{col} — After Winsorization")

    plt.tight_layout()
    path = os.path.join(figures_dir, f"outlier_{col}.png")
    plt.savefig(path)
    plt.close()
    logger.info(f"    → Plot saved: {path}")


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    df = pd.read_excel("data/raw/dataset.xlsx")
    df_clean = handle_outliers(df)
    print(df_clean[["Quantity", "UnitPrice", "ItemsInCart", "TotalPrice"]].describe())
