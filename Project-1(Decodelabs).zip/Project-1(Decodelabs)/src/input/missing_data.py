"""
Phase 1 — Input Fidelity
missing_data.py

Decision matrix:
  < 5%       → drop rows
  5–20%      → median (numeric) / mode (categorical)
  > 20%      → KNN imputation
  Categorical → fill with 'Unknown' or mode
"""

import logging
import pandas as pd
import numpy as np
import yaml
from sklearn.impute import KNNImputer

logger = logging.getLogger(__name__)


def load_config(config_path: str = "configs/imputation_config.yaml") -> dict:
    with open(config_path) as f:
        return yaml.safe_load(f)


def calculate_missingness(df: pd.DataFrame) -> pd.Series:
    """Return missingness proportion per feature."""
    return df.isnull().mean()


def handle_missing_data(df: pd.DataFrame, config_path: str = "configs/imputation_config.yaml") -> pd.DataFrame:
    """
    Apply the Missing Data Decision Matrix from the IPO pipeline.
    
    Returns cleaned DataFrame and logs every decision made.
    """
    cfg = load_config(config_path)["imputation"]
    low_thresh  = cfg["low_threshold"]
    high_thresh = cfg["high_threshold"]
    skip_cols   = cfg.get("skip_columns", [])
    knn_k       = cfg.get("knn_neighbors", 5)
    cat_fill    = cfg.get("categorical_fill", "Unknown")

    df = df.copy()
    missingness = calculate_missingness(df)

    logger.info("=== Missing Data Decision Matrix ===")
    logger.info(f"\n{missingness[missingness > 0]}")

    numeric_cols     = df.select_dtypes(include=[np.number]).columns.tolist()
    categorical_cols = df.select_dtypes(include=["object", "category"]).columns.tolist()

    knn_targets = []   # collect columns needing KNN (batch them)

    for col in df.columns:
        if col in skip_cols:
            logger.info(f"  SKIP  '{col}' — in skip list")
            continue

        ratio = missingness[col]
        if ratio == 0:
            continue

        logger.info(f"  '{col}': {ratio:.1%} missing → ")

        if col in categorical_cols:
            # Categorical always filled with mode or 'Unknown'
            fill_val = df[col].mode().iloc[0] if not df[col].mode().empty else cat_fill
            df[col] = df[col].fillna(fill_val)
            logger.info(f"categorical fill → '{fill_val}'")

        elif ratio < low_thresh:
            before = len(df)
            df = df.dropna(subset=[col])
            logger.info(f"DROP rows (< {low_thresh:.0%}) — removed {before - len(df)} rows")

        elif ratio <= high_thresh:
            median_val = df[col].median()
            df[col] = df[col].fillna(median_val)
            logger.info(f"MEDIAN impute → {median_val:.4f}")

        else:
            knn_targets.append(col)
            logger.info(f"queued for KNN (> {high_thresh:.0%})")

    # Batch KNN on all high-missingness numeric columns
    if knn_targets:
        logger.info(f"Running KNNImputer (k={knn_k}) on: {knn_targets}")
        imputer = KNNImputer(n_neighbors=knn_k)
        df[knn_targets] = imputer.fit_transform(df[knn_targets])

    remaining = df.isnull().sum().sum()
    logger.info(f"Missing values remaining after imputation: {remaining}")
    return df


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    df = pd.read_excel("data/raw/dataset.xlsx")
    print("Before:\n", df.isnull().sum())
    df_clean = handle_missing_data(df)
    print("\nAfter:\n", df_clean.isnull().sum())
