"""
Phase 1 — Input Fidelity
distribution_guard.py

Verifies that numeric feature distributions remain within acceptable
statistical bounds after cleaning — guards against accidental distortion.
"""

import logging
import pandas as pd
import numpy as np
from scipy import stats

logger = logging.getLogger(__name__)

NUMERIC_COLS = ["Quantity", "UnitPrice", "ItemsInCart", "TotalPrice"]


def check_distribution_variance(df_before: pd.DataFrame, df_after: pd.DataFrame) -> dict:
    """
    Compare mean, std, skew before and after cleaning.
    Warns if std changes > 15% (sign of over-imputation or aggressive clipping).
    """
    report = {}

    for col in NUMERIC_COLS:
        if col not in df_before.columns or col not in df_after.columns:
            continue

        before_mean = df_before[col].mean()
        after_mean  = df_after[col].mean()
        before_std  = df_before[col].std()
        after_std   = df_after[col].std()
        before_skew = df_before[col].skew()
        after_skew  = df_after[col].skew()

        std_change_pct = abs(after_std - before_std) / (before_std + 1e-9) * 100

        status = "OK"
        if std_change_pct > 15:
            status = "WARNING"
            logger.warning(f"  '{col}': std changed {std_change_pct:.1f}% — possible over-imputation")
        else:
            logger.info(f"  '{col}': std change {std_change_pct:.1f}% — {status}")

        report[col] = {
            "before_mean": round(before_mean, 4),
            "after_mean":  round(after_mean, 4),
            "before_std":  round(before_std, 4),
            "after_std":   round(after_std, 4),
            "before_skew": round(before_skew, 4),
            "after_skew":  round(after_skew, 4),
            "std_change_pct": round(std_change_pct, 2),
            "status": status
        }

    return report


def run_normality_check(df: pd.DataFrame) -> dict:
    """Shapiro-Wilk test on numeric columns (sample ≤ 5000)."""
    results = {}
    for col in NUMERIC_COLS:
        if col not in df.columns:
            continue
        sample = df[col].dropna().sample(min(500, len(df)), random_state=42)
        stat, p = stats.shapiro(sample)
        results[col] = {"statistic": round(stat, 4), "p_value": round(p, 4),
                        "normal": p > 0.05}
        logger.info(f"  Normality '{col}': p={p:.4f} → {'Normal' if p > 0.05 else 'Non-Normal'}")
    return results


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    df = pd.read_excel("data/raw/dataset.xlsx")
    print(run_normality_check(df))
