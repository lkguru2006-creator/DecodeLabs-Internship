"""
Phase 3 — Contracts & Serving
feature_store.py

Feast-style offline/online feature store using parquet + CSV.
(Uses pandas parquet via pyarrow fallback to CSV if pyarrow unavailable)
"""

import logging
import os
import pandas as pd

logger = logging.getLogger(__name__)

OFFLINE_PATH = "data/processed/offline_feature_store.csv"
ONLINE_PATH  = "data/processed/online_feature_cache.csv"


def push_to_offline_store(df: pd.DataFrame, path: str = OFFLINE_PATH) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    df.to_csv(path, index=False)
    logger.info(f"  ✓ Offline store materialized: {path} ({len(df)} rows, {df.shape[1]} features)")


def push_to_online_store(df: pd.DataFrame, key_col: str = "CustomerID",
                          path: str = ONLINE_PATH) -> None:
    if key_col not in df.columns:
        logger.warning(f"  Key column '{key_col}' not found — skipping online store push")
        return

    ts_col = "event_timestamp" if "event_timestamp" in df.columns else None
    if ts_col:
        latest = df.sort_values(ts_col).groupby(key_col).last().reset_index()
    else:
        latest = df.groupby(key_col).last().reset_index()

    os.makedirs(os.path.dirname(path), exist_ok=True)
    latest.to_csv(path, index=False)
    logger.info(f"  ✓ Online store synced: {path} ({len(latest)} unique entities)")


def get_online_features(customer_ids: list, path: str = ONLINE_PATH) -> pd.DataFrame:
    cache = pd.read_csv(path)
    result = cache[cache["CustomerID"].isin(customer_ids)]
    logger.info(f"  Online lookup: {len(result)} of {len(customer_ids)} entities found")
    return result


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    df = pd.read_excel("data/raw/dataset.xlsx")
    push_to_offline_store(df)
    push_to_online_store(df)
    print("Feature store push complete.")
