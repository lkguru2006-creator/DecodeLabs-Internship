"""
Phase 3 — Contracts & Serving
point_in_time.py

Enforces temporal integrity — prevents future data leaking into training labels.
Implements point-in-time correct joins using the Date column as the event timestamp.
"""

import logging
import pandas as pd
import numpy as np

logger = logging.getLogger(__name__)


def enforce_temporal_ordering(df: pd.DataFrame, date_col: str = "Date") -> pd.DataFrame:
    """
    Sort by date ascending.
    Ensures no future rows appear before past rows in the training split.
    """
    df = df.copy()
    df[date_col] = pd.to_datetime(df[date_col])
    df = df.sort_values(date_col).reset_index(drop=True)
    logger.info(f"  Sorted by '{date_col}' ascending: {df[date_col].min()} → {df[date_col].max()}")
    return df


def create_temporal_train_test_split(
    df: pd.DataFrame,
    date_col: str = "Date",
    cutoff_date: str = None,
    train_ratio: float = 0.80
) -> tuple:
    """
    Point-in-time correct train/test split.
    
    Uses a date cutoff rather than random shuffle — random shuffle causes
    data leakage by including future orders in training set.
    
    Args:
        cutoff_date: ISO date string e.g. "2024-12-31". If None, uses train_ratio.
        train_ratio: Used only if cutoff_date is None.
    
    Returns:
        (df_train, df_test)
    """
    df = enforce_temporal_ordering(df, date_col)

    if cutoff_date:
        cutoff = pd.Timestamp(cutoff_date)
        df_train = df[df[date_col] <= cutoff].copy()
        df_test  = df[df[date_col] >  cutoff].copy()
    else:
        n_train  = int(len(df) * train_ratio)
        df_train = df.iloc[:n_train].copy()
        df_test  = df.iloc[n_train:].copy()

    logger.info(f"  Train: {len(df_train)} rows | {df_train[date_col].min()} → {df_train[date_col].max()}")
    logger.info(f"  Test:  {len(df_test)}  rows | {df_test[date_col].min()} → {df_test[date_col].max()}")
    logger.info("  ✓ No future data in training set — point-in-time integrity maintained")
    return df_train, df_test


def add_event_timestamp(df: pd.DataFrame, date_col: str = "Date") -> pd.DataFrame:
    """
    Rename date column to 'event_timestamp' — Feast convention.
    Feast uses this column for all point-in-time joins.
    """
    df = df.copy()
    df = df.rename(columns={date_col: "event_timestamp"})
    df["event_timestamp"] = pd.to_datetime(df["event_timestamp"])
    logger.info("  Renamed 'Date' → 'event_timestamp' for Feast compatibility")
    return df


def check_for_leakage(df_train: pd.DataFrame, df_test: pd.DataFrame,
                      date_col: str = "event_timestamp") -> bool:
    """Assert that no test dates appear in train set."""
    if date_col not in df_train.columns or date_col not in df_test.columns:
        logger.warning("  event_timestamp column not found — skipping leakage check")
        return True

    train_max = df_train[date_col].max()
    test_min  = df_test[date_col].min()
    no_leak   = train_max < test_min

    if no_leak:
        logger.info(f"  ✓ Leakage check PASSED: train_max={train_max}, test_min={test_min}")
    else:
        logger.error(f"  ✗ DATA LEAKAGE DETECTED: train_max={train_max} overlaps test_min={test_min}")
    return no_leak


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    df = pd.read_excel("data/raw/dataset.xlsx")
    df_train, df_test = create_temporal_train_test_split(df)
    df_train = add_event_timestamp(df_train)
    df_test  = add_event_timestamp(df_test)
    check_for_leakage(df_train, df_test)
    print(f"\nTrain rows: {len(df_train)} | Test rows: {len(df_test)}")
