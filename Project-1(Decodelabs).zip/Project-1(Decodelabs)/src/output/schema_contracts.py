"""
Phase 3 — Contracts & Serving
schema_contracts.py

Implements runtime validation contracts using pure pandas/numpy.
(Pandera fallback — same logic, no external dependency required)
"""

import logging
import os
import pandas as pd
import numpy as np

logger = logging.getLogger(__name__)
FAILURE_LOG = "contracts/failure_logs/failure_cases.log"

VALID_PRODUCTS       = {"Desk","Monitor","Phone","Tablet","Chair","Printer","Laptop","Keyboard"}
VALID_PAYMENT        = {"Debit Card","Online","Credit Card","Gift Card","Cash"}
VALID_STATUS         = {"Pending","Shipped","Delivered","Returned","Cancelled"}
VALID_REFERRAL       = {"Instagram","Referral","Email","Facebook","Google"}
VALID_COUPON         = {"SAVE10","FREESHIP","WINTER15"}


def validate_raw_input(df: pd.DataFrame) -> pd.DataFrame:
    logger.info("=== Schema Contracts: Validating Raw Input ===")
    errors = []
    os.makedirs(os.path.dirname(FAILURE_LOG), exist_ok=True)

    if df["Quantity"].lt(1).any():
        errors.append(f"Quantity < 1 in {df['Quantity'].lt(1).sum()} rows")
    if df["UnitPrice"].le(0).any():
        errors.append(f"UnitPrice <= 0 in {df['UnitPrice'].le(0).sum()} rows")
    if df["TotalPrice"].le(0).any():
        errors.append(f"TotalPrice <= 0 in {df['TotalPrice'].le(0).sum()} rows")
    if df["ItemsInCart"].lt(1).any():
        errors.append(f"ItemsInCart < 1 in {df['ItemsInCart'].lt(1).sum()} rows")

    invalid_products = ~df["Product"].isin(VALID_PRODUCTS)
    if invalid_products.any():
        errors.append(f"Unknown Product values: {df.loc[invalid_products,'Product'].unique()}")

    invalid_status = ~df["OrderStatus"].isin(VALID_STATUS)
    if invalid_status.any():
        errors.append(f"Unknown OrderStatus values: {df.loc[invalid_status,'OrderStatus'].unique()}")

    if errors:
        _log_failures(errors, "raw_input")
        for e in errors:
            logger.warning(f"  ⚠ CONTRACT: {e}")
    else:
        logger.info("  ✓ Raw input schema validation PASSED")

    return df


def validate_processed_output(df: pd.DataFrame) -> pd.DataFrame:
    logger.info("=== Schema Contracts: Validating Processed Output ===")
    errors = []

    required = ["Quantity", "UnitPrice", "ItemsInCart", "TotalPrice"]
    for col in required:
        if col in df.columns:
            nulls = df[col].isnull().sum()
            if nulls > 0:
                errors.append(f"'{col}' has {nulls} nulls in processed output")
            if df[col].lt(0).any():
                errors.append(f"'{col}' has negative values")

    if errors:
        _log_failures(errors, "processed_output")
        for e in errors:
            logger.warning(f"  ⚠ CONTRACT: {e}")
    else:
        logger.info("  ✓ Processed output schema validation PASSED")

    return df


def _log_failures(errors: list, stage: str):
    os.makedirs(os.path.dirname(FAILURE_LOG), exist_ok=True)
    with open(FAILURE_LOG, "a") as f:
        f.write(f"\n{'='*60}\nSTAGE: {stage}\n{'='*60}\n")
        for e in errors:
            f.write(f"  {e}\n")
    logger.info(f"  Failure cases written to {FAILURE_LOG}")


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    df = pd.read_excel("data/raw/dataset.xlsx")
    validate_raw_input(df)
