"""
Phase 2 — Vectorized Computation Engine
collinearity.py

Algorithm (from slides):
  1. Build absolute Pearson correlation matrix
  2. Identify pairs where |r| > threshold (default 0.80)
  3. For each flagged pair, correlate both features against target y
  4. Drop the WEAKER one — never drop blindly
"""

import logging
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import yaml
import os

logger = logging.getLogger(__name__)


def load_config(config_path: str = "configs/imputation_config.yaml") -> dict:
    with open(config_path) as f:
        return yaml.safe_load(f)


def build_correlation_matrix(df: pd.DataFrame) -> pd.DataFrame:
    """Pearson correlation matrix on all numeric columns."""
    return df.select_dtypes(include=[np.number]).corr(method="pearson").abs()


def find_collinear_pairs(corr_matrix: pd.DataFrame, threshold: float = 0.80) -> list:
    """
    Return list of (col_a, col_b, correlation) for pairs above threshold.
    Upper triangle only — avoids duplicates.
    """
    pairs = []
    cols = corr_matrix.columns
    for i in range(len(cols)):
        for j in range(i + 1, len(cols)):
            r = corr_matrix.iloc[i, j]
            if r >= threshold:
                pairs.append((cols[i], cols[j], round(r, 4)))
    return pairs


def select_feature_to_drop(df: pd.DataFrame, col_a: str, col_b: str, target: str) -> str:
    """
    Correlate col_a and col_b against target.
    Drop the one with LOWER correlation to target.
    """
    if target not in df.columns:
        # No target available — drop col_b by convention
        logger.warning(f"  Target '{target}' not found — dropping '{col_b}' by convention")
        return col_b

    r_a = df[[col_a, target]].corr().iloc[0, 1]
    r_b = df[[col_b, target]].corr().iloc[0, 1]

    drop = col_b if abs(r_a) >= abs(r_b) else col_a
    keep = col_a if drop == col_b else col_b
    logger.info(f"  Pair ({col_a} r={r_a:.3f}, {col_b} r={r_b:.3f}) → DROP '{drop}', KEEP '{keep}'")
    return drop


def remove_collinearity(
    df: pd.DataFrame,
    config_path: str = "configs/imputation_config.yaml",
    save_heatmap: bool = True,
    figures_dir: str = "reports/figures/"
) -> pd.DataFrame:
    """
    Full collinearity eradication pipeline.
    Returns cleaned DataFrame with collinear features removed.
    """
    cfg       = load_config(config_path)["collinearity"]
    threshold = cfg.get("correlation_threshold", 0.80)
    target    = cfg.get("target_column", "TotalPrice")

    df = df.copy()
    logger.info("=== Collinearity Eradication ===")

    corr_matrix = build_correlation_matrix(df)

    if save_heatmap:
        _save_heatmap(corr_matrix, "corr_before", figures_dir)

    pairs = find_collinear_pairs(corr_matrix, threshold)

    if not pairs:
        logger.info(f"  No collinear pairs found above |r| = {threshold}")
        return df

    logger.info(f"  Found {len(pairs)} collinear pair(s) above |r| = {threshold}:")
    for a, b, r in pairs:
        logger.info(f"    {a} ↔ {b}  |r| = {r}")

    dropped = set()
    for col_a, col_b, _ in pairs:
        if col_a in dropped or col_b in dropped:
            continue  # already removed in a previous iteration
        to_drop = select_feature_to_drop(df, col_a, col_b, target)
        dropped.add(to_drop)

    cols_to_drop = [c for c in dropped if c in df.columns]
    df = df.drop(columns=cols_to_drop)
    logger.info(f"  Dropped columns: {cols_to_drop}")
    logger.info(f"  Shape after collinearity removal: {df.shape}")

    if save_heatmap:
        _save_heatmap(build_correlation_matrix(df), "corr_after", figures_dir)

    return df, cols_to_drop


def _save_heatmap(corr: pd.DataFrame, name: str, figures_dir: str):
    os.makedirs(figures_dir, exist_ok=True)
    fig, ax = plt.subplots(figsize=(max(8, len(corr)), max(6, len(corr) - 2)))
    im = ax.imshow(corr.values, cmap="coolwarm", vmin=0, vmax=1)
    ax.set_xticks(range(len(corr.columns)))
    ax.set_yticks(range(len(corr.columns)))
    ax.set_xticklabels(corr.columns, rotation=45, ha="right", fontsize=8)
    ax.set_yticklabels(corr.columns, fontsize=8)
    plt.colorbar(im, ax=ax)
    ax.set_title(f"Pearson Correlation Heatmap — {name}")
    plt.tight_layout()
    path = os.path.join(figures_dir, f"{name}.png")
    plt.savefig(path)
    plt.close()
    logger.info(f"  Heatmap saved: {path}")


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    df = pd.read_excel("data/raw/dataset.xlsx")
    # Quick numeric-only test
    numeric_df = df.select_dtypes(include=[np.number])
    result = remove_collinearity(numeric_df)
    if isinstance(result, tuple):
        df_clean, dropped = result
        print("Dropped:", dropped)
        print("Remaining numeric cols:", list(df_clean.columns))
