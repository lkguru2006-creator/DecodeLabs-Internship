"""
Phase 2 — Vectorized Computation Engine
vectorizer.py

Rule: ZERO Python loops on DataFrame rows.
All transformations use NumPy SIMD block operations or pandas vectorized methods.
"""

import logging
import pandas as pd
import numpy as np

logger = logging.getLogger(__name__)


def normalize_numeric(df: pd.DataFrame, columns: list) -> pd.DataFrame:
    """
    Min-Max normalization using vectorized NumPy ops.
    NO loops — entire column processed as a C-level array.
    """
    df = df.copy()
    for col in columns:
        if col not in df.columns:
            continue
        col_min = df[col].min()
        col_max = df[col].max()
        denom = col_max - col_min
        if denom == 0:
            logger.warning(f"  '{col}' has zero range — skipping normalization")
            continue
        # Pure NumPy vectorized — no Python loop
        df[col] = (df[col].values - col_min) / denom
        logger.info(f"  Normalized '{col}' → [0, 1]")
    return df


def standardize_numeric(df: pd.DataFrame, columns: list) -> pd.DataFrame:
    """Z-score standardization: (x - mean) / std — fully vectorized."""
    df = df.copy()
    for col in columns:
        if col not in df.columns:
            continue
        mean = df[col].mean()
        std  = df[col].std()
        if std == 0:
            logger.warning(f"  '{col}' std=0 — skipping standardization")
            continue
        df[col] = (df[col].values - mean) / std
        logger.info(f"  Standardized '{col}': mean={mean:.2f}, std={std:.2f}")
    return df


def vectorized_date_features(df: pd.DataFrame, date_col: str = "Date") -> pd.DataFrame:
    """
    Extract date parts using pandas dt accessor — vectorized, no loops.
    Adds: Year, Month, DayOfWeek, Quarter, IsWeekend
    """
    df = df.copy()
    if date_col not in df.columns:
        logger.warning(f"  Date column '{date_col}' not found")
        return df

    dt = pd.to_datetime(df[date_col])
    df["Year"]       = dt.dt.year.values
    df["Month"]      = dt.dt.month.values
    df["DayOfWeek"]  = dt.dt.dayofweek.values      # 0=Mon, 6=Sun
    df["Quarter"]    = dt.dt.quarter.values
    df["IsWeekend"]  = (dt.dt.dayofweek >= 5).astype(int).values  # vectorized bool → int
    logger.info(f"  Date features extracted from '{date_col}': Year, Month, DayOfWeek, Quarter, IsWeekend")
    return df


def vectorized_revenue_features(df: pd.DataFrame) -> pd.DataFrame:
    """
    Compute revenue-based features using vectorized NumPy arithmetic.
    """
    df = df.copy()
    if "TotalPrice" in df.columns and "Quantity" in df.columns:
        # Effective unit price (handles discounts baked into TotalPrice)
        df["EffectiveUnitPrice"] = np.where(
            df["Quantity"] > 0,
            df["TotalPrice"].values / df["Quantity"].values,
            0.0
        )
        logger.info("  Feature: EffectiveUnitPrice = TotalPrice / Quantity")

    if "ItemsInCart" in df.columns and "TotalPrice" in df.columns:
        df["RevenuePerCartItem"] = np.where(
            df["ItemsInCart"] > 0,
            df["TotalPrice"].values / df["ItemsInCart"].values,
            0.0
        )
        logger.info("  Feature: RevenuePerCartItem = TotalPrice / ItemsInCart")

    return df


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    df = pd.read_excel("data/raw/dataset.xlsx")
    df = vectorized_date_features(df)
    df = vectorized_revenue_features(df)
    print(df[["Year", "Month", "DayOfWeek", "Quarter", "IsWeekend",
              "EffectiveUnitPrice", "RevenuePerCartItem"]].head())
