"""
Phase 2 — Vectorized Computation Engine
encoder.py

Rules:
  - Ordinal / low-cardinality (known order) → Label Encoding
  - Nominal (no order)                       → One-Hot Encoding
  - NEVER label-encode nominal data (introduces false ordinality)
"""

import logging
import pandas as pd
import numpy as np
from sklearn.preprocessing import LabelEncoder

logger = logging.getLogger(__name__)

# ── Column encoding map (dataset-specific) ──────────────────────────────────
# OrderStatus has a natural severity/progress order → Label Encode
ORDINAL_COLUMNS = {
    "OrderStatus": ["Pending", "Shipped", "Delivered", "Returned", "Cancelled"]
}

# Nominal columns → One-Hot Encode (no order implied)
NOMINAL_COLUMNS = ["Product", "PaymentMethod", "ReferralSource", "CouponCode"]

# Columns to drop before encoding (IDs, free-text, dates handled elsewhere)
DROP_BEFORE_ENCODE = ["OrderID", "CustomerID", "ShippingAddress", "TrackingNumber", "Date"]


def label_encode(df: pd.DataFrame) -> pd.DataFrame:
    """
    Label-encode ordinal columns using an explicit category order.
    Explicit ordering prevents sklearn from defaulting to alphabetical.
    """
    df = df.copy()
    for col, order in ORDINAL_COLUMNS.items():
        if col not in df.columns:
            logger.warning(f"  Ordinal column '{col}' not in DataFrame — skipping")
            continue
        cat = pd.Categorical(df[col], categories=order, ordered=True)
        df[col + "_encoded"] = cat.codes        # -1 for unseen values
        logger.info(f"  Label encoded '{col}' with order: {order}")
    return df


def one_hot_encode(df: pd.DataFrame) -> pd.DataFrame:
    """
    One-hot encode nominal columns via pd.get_dummies (vectorized, no loops).
    Prefix = column name to avoid collision. Drop first to avoid dummy trap.
    """
    df = df.copy()
    cols_present = [c for c in NOMINAL_COLUMNS if c in df.columns]
    if not cols_present:
        logger.warning("  No nominal columns found for OHE")
        return df

    df = pd.get_dummies(df, columns=cols_present, prefix=cols_present, drop_first=False, dtype=int)
    logger.info(f"  One-Hot encoded: {cols_present}")
    logger.info(f"  DataFrame shape after OHE: {df.shape}")
    return df


def drop_identifier_columns(df: pd.DataFrame) -> pd.DataFrame:
    """Drop ID / free-text columns that carry no predictive signal."""
    df = df.copy()
    cols_to_drop = [c for c in DROP_BEFORE_ENCODE if c in df.columns]
    df = df.drop(columns=cols_to_drop)
    logger.info(f"  Dropped identifier columns: {cols_to_drop}")
    return df


def encode_features(df: pd.DataFrame) -> pd.DataFrame:
    """Full encoding pipeline: drop → label encode → one-hot encode."""
    logger.info("=== Categorical Encoding ===")
    df = drop_identifier_columns(df)
    df = label_encode(df)
    df = one_hot_encode(df)
    return df


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    df = pd.read_excel("data/raw/dataset.xlsx")
    df_encoded = encode_features(df)
    print("Shape:", df_encoded.shape)
    print("Columns:", list(df_encoded.columns))
    print(df_encoded.head(3))
